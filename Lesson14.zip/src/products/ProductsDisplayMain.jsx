import React from "react";
import CatagoryCard from "../components/displays/CatagoryCard";

export default function ProductsDisplayMain({ productsAll }) {
  return (
    <div className='MainContainer'>
      {productsAll.map((cat, index) => (
        <CatagoryCard key={index} prod={cat} index={index} />
      ))}
    </div>
  );
}
