import React from "react";

export default function SingleProductview() {
  return <div>SingleProductview</div>;
}
