import { createUserWithEmailAndPassword, GoogleAuthProvider, signInAnonymously, signInWithEmailAndPassword, signInWithPopup, signOut } from "firebase/auth";
import { doc, collection, query, where, getDocs, setDoc } from "firebase/firestore";
import { FIREBASE_AUTH, FIREBASE_FIRESTORE } from "./FirebaseConfig";

const PathString = "USERS";

// Sign up using email and password (SignUp Page)
export function RegisterEmailPass(email, password) {
  // this is the firebase call that handles the auth of a new user signing up with our site. This call return a Promise of type FirebaseUser
  return createUserWithEmailAndPassword(FIREBASE_AUTH, email, password);
}

// Sign in
export function LoginEmailPass(email, password) {
  // this is the firebase call that handles the auth of a user signing in to our site. This call return a Promise of type FirebaseUser
  return signInWithEmailAndPassword(FIREBASE_AUTH, email, password);
}

// Log out from all forms of auth
export function Logout() {
  signOut(FIREBASE_AUTH);
  window.location.replace("/");
}

// Sign in/up with google pop up
export function SignInWithGoogle() {
  // is the way we coms with firebase to know how to log in
  const provider = new GoogleAuthProvider();
  //   the firebase function that allows us to sign in with gooogle via a pop up screen
  //  it will return to us a promise of type FirebaseUser
  return signInWithPopup(FIREBASE_AUTH, provider);
}

// Sign in/up with anon
export function SignInAnon() {
  return signInAnonymously(FIREBASE_AUTH);
}

// Create a new User from a Sign up
// async asycronious meaning allows other functions to co run while it is running
export async function CreateNewUser(uid, user) {
  //   Checks that user does exist
  const isUser = user !== undefined && user !== null ? true : false;
  //   Checks if the user has a display name (only Google auth does)
  const dn = isUser && user.displayName !== null ? user.displayName : "";

  //   The new user object we want to create
  const payload = {
    displayName: dn.length > 0 ? dn : `${user.displayName}`,
    email: isUser ? user.email : "",
    profileUrl: isUser && user.profileUrl ? user.profileUrl : "", //(Google)
    uid: uid,
    role: "user"
  };

  //   FIREBASE FIRESTORE IMPLEMENTATION

  // this is a refrence to a single document in a collection because we have the base path as well as a sub path ie: USERS/uid
  const Ref = collection(FIREBASE_FIRESTORE, PathString);
  const docRef = doc(FIREBASE_FIRESTORE, PathString, uid);

  //   Same structure as an sql query
  //          query(location  type of query == where a==b)
  const q = query(Ref, where("uid", "==", `${uid}`));

  //   if query matched an array of results from match will be returned to us
  const querySnapshot = await getDocs(q);
  console.log("qs", querySnapshot.docs.length); //.docs.length

  // Checked that user does not exit in our db that way we do not have duplicate values for users this is very relevant when we add this to our anon and goole auth methods

  if (querySnapshot.docs.length == 0) {
    //   create a db entry:
    await setDoc(docRef, payload) // addDoc
      .then((res) => {
        console.log("Created new User entry in db ", res);
      })
      .catch((err) => {
        console.log("ERROR Cannot Create New user entry in db ", err);
      });
  }
}
