import React from "react";
import { useNavigate } from "react-router-dom";
import { RoutesObj } from "../../routes/AllRoutes";

export default function CatagoryCard({ prod }) {
  const navigate = useNavigate();
  return (
    <button className='Card' onClick={() => navigate(`${RoutesObj.non_visual.catsLanding.pathClean}${prod.name}`)}>
      <img src={prod.img} alt='broken' />
      <h1>{prod.name}</h1>
      <h2>{prod.desc}</h2>
    </button>
  );
}
