import React from "react";

export default function FooterBar() {
  return <div>FooterBar</div>;
}
