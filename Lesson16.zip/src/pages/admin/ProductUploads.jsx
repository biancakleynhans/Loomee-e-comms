import React from "react";
import { useData } from "../../firebase/FirebaseDataHook";

/* 
Choice of how to gather input from admin user to safe to the db this is your assignment 

Reusable code if possible for create and update


Safety check only allow acess to this page if role === "admin"

Use useData hook to acess all of the crud functionalities 
*/
export default function ProductUploads() {
  const { CreateProduct } = useData();

  const mainCat = ["male", "female", "kids"]; //select.option
  const SubCat = ["shoes", "shirts", "dresses"]; //select.option
  // 3x input fields === name, desc, price, stockLevel
  // 1x image upload === button, input

  let test = { name: "Test", desc: "test", price: 1000.0, stockLevel: 10, images: [""], mainCat: "Male", subCat: "Shoes" };
  return (
    <div>
      Product Uploads
      <button
        onClick={() => {
          CreateProduct(test);
        }}>
        Add
      </button>
    </div>
  );
}
