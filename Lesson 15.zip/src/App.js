import Routing from "./routes/Routing";

function App() {
  return (
    <div className='App'>
      <Routing />
    </div>
  );
}

export default App;
