import React, { useState } from "react";
import CatagoryCard from "../components/displays/CatagoryCard";

export default function CatagoryView() {
  const [allProducts, setallProducts] = useState([
    {
      name: "SubCat",
      desc: "desc",
      img: "https://picsum.photos/seed/picsum/200/300",
      products: [
        { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" },
        { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" },
        { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" },
        { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" }
      ]
    },
    { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" },
    { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" },
    { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" }
  ]);
  return (
    <div>
      <h1>Sub Catagory View</h1>
      {allProducts.map((cat, index) => (
        <CatagoryCard key={index} prod={cat} index={index} />
      ))}
    </div>
  );
}
