import React from "react";
import { NavLink } from "react-router-dom";
import { AllRoutes } from "../../routes/AllRoutes";

export default function NavBar() {
  return (
    <>
      {AllRoutes.reverse().map((entry, index) => (
        <NavLink className='navItem' key={index} to={entry.path}>
          {entry.name}
        </NavLink>
      ))}
    </>
  );
}
