import React, { useState } from "react";
import HeaderBar from "../../components/headers_footers/HeaderBar";
import ProductsDisplayMain from "../../products/ProductsDisplayMain";

// Just add your layout
export default function Home() {
  const [allInventory, setallInventory] = useState([
    {
      name: "Catagory",
      desc: "desc",
      img: "https://picsum.photos/seed/picsum/200/300",
      subCats: [
        {
          name: "SubCat",
          desc: "desc",
          img: "https://picsum.photos/seed/picsum/200/300",
          products: [
            { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" },
            { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" },
            { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" },
            { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" }
          ]
        },
        { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" },
        { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" },
        { name: "SubCat", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300" }
      ]
    },
    { name: "Catagory", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300", products: [] },
    { name: "Catagory", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300", products: [] },
    { name: "Catagory", desc: "desc", img: "https://picsum.photos/seed/picsum/200/300", products: [] }
  ]);
  return (
    <>
      <HeaderBar />
      <h1>Welcome to Black Wolfs Moon online shop</h1>
      <ProductsDisplayMain productsAll={allInventory} />
    </>
  );
}
