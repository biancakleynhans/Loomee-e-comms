import React from "react";
import AuthForm from "../../components/reusables/AuthForm";
/* form=>
    email & pass
    Bonus ensure add confirm password field
    Stop user from using sign up if passwords do not match 

    Form validation
*/

export default function SignUp() {
  function submitSignUp(email, pass) {
    console.log("email and pass: ", email, pass);
    // do firebase auth call here for signup with email and pass
  }

  return (
    <>
      <button onClick={() => submitSignUp()}>text</button>

      <h1>Sign Up Page</h1>
      <AuthForm type='Sign Up' onFinalize={(email, pass) => submitSignUp(email, pass)} />
    </>
  );
}
