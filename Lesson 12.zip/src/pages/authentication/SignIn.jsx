import React from "react";
import { NavLink } from "react-router-dom";
import AuthForm from "../../components/reusables/AuthForm";
import { RoutesObj } from "../../routes/AllRoutes";

/* 
 google button
 anom button
 form => email & pass input X 2
  Form validation
*/

export default function SignIn() {
  // Sign up with email and password
  function submitSignIn(email, passw) {
    console.log("email and pass: ", email, passw);
    // do firebase auth call here for signup with email and pass
  }

  function googleBTN() {}

  function anonBTN() {}

  return (
    <>
      <h1>Sign In Page</h1>
      <br />

      <h2>Sign in with email and password </h2>
      <br />
      <AuthForm type='Sign In' onFinalize={(email, pass) => submitSignIn(email, pass)} />
      <br />

      <button onClick={() => googleBTN()}>Sign in with Google</button>

      <br />

      <button onClick={() => anonBTN()}>Sign in Anonomously</button>

      <br />
      <br />

      <p>
        Don't have an account <NavLink to={RoutesObj.visual.sign_up.path}>{RoutesObj.visual.sign_up.name}</NavLink>
      </p>
    </>
  );
}
