import React, { useEffect, useState } from "react";
import HeaderBar from "../../components/headers_footers/HeaderBar";
import { useData } from "../../firebase/FirebaseDataHook";

export default function SingleProductview() {
  const { Products } = useData();
  const [final, setfinal] = useState(null);

  useEffect(() => {
    let path = window.location.href;
    let pathSplit = path.split("/");

    let cat = pathSplit[pathSplit.length - 3]; //last entry in array is our cat
    let sub = pathSplit[pathSplit.length - 2]; //last entry in array is our cat
    let id = pathSplit[pathSplit.length - 1]; //last entry in array is our cat

    if (Products !== null) {
      let subCatObj = Products[cat];

      if (subCatObj !== null) {
        let prods = Products[cat][sub];

        if (prods !== null) {
          let temp = prods.products[id];
          if (temp !== null) {
            setfinal(temp);
            console.log("URL: ", path, pathSplit, cat, sub, subCatObj, prods, temp);
          }
        }
      }
    }
  }, []);

  return (
    <div>
      <HeaderBar />
      <h1>SingleProductview</h1>
    </div>
  );
}
