import React from "react";
import HeaderBar from "../../components/headers_footers/HeaderBar";

// Just add your layout
export default function Home() {
  return (
    <>
      <HeaderBar />
      <h1>Home Page</h1>
    </>
  );
}
