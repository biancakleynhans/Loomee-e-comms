import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import { RoutesObj } from "../../routes/AllRoutes";
import { validEmail } from "../../utils/Util_fuctions";

/*
 input for email button reset pass
 Form validation
*/
export default function ForgotPass() {
  const [email, setemail] = useState("");
  const [errorMsg, seterrorMsg] = useState("");

  function checkEmail(e) {
    setemail(e.target.value);
    let isVal = validEmail(e.target.value);
    console.log("????", isVal);

    if (isVal) {
      seterrorMsg("");
    } else {
      seterrorMsg("Email is incorrect format");
    }
  }

  function getRecover() {}
  return (
    <>
      <h1>Forgot password Page</h1>
      <h2>To recieve a recovery email please enter your email adress below</h2>
      <br />
      <br />
      <label>Email: </label>
      <input type='text' placeholder='janeDoe@gmail.com' value={email} onChange={(e) => checkEmail(e)} />
      <br />
      <p>
        Go back to <NavLink to={RoutesObj.sign_in.path}>{RoutesObj.sign_in.name}</NavLink>
      </p>
      <br />
      <button onClick={() => getRecover()}>Get recovery email now</button>
      {errorMsg.length > 0 ? <p style={{ fontSize: "20px", color: "red" }}>{errorMsg}</p> : <></>}
    </>
  );
}
