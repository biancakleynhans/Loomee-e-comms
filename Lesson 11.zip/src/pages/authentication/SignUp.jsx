import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import AuthForm from "../../components/reusables/AuthForm";
import { RoutesObj } from "../../routes/AllRoutes";
import { validEmail } from "../../utils/Util_fuctions";
/* form=>
    email & pass
    Bonus ensure add confirm password field
    Stop user from using sign up if passwords do not match 

    Form validation
*/

export default function SignUp() {
  function submitSignUp(email, pass) {
    console.log("email and pass: ", email, pass);
    // do firebase auth call here for signup with email and pass
  }

  return (
    <>
      <h1>Sign Up Page</h1>
      <AuthForm type='Sign Up' onFinalize={(email, pass) => submitSignUp(email, pass)} />
    </>
  );
}
